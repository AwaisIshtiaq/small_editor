import test from "node:test";
import assert from "node:assert/strict";
import {
  buildLines,
  buildPageModel,
  countByPage,
  describeMatches,
  filterTools,
  findInDocument,
  findInPage,
  fold,
  geometryForRange,
  isWordChar,
  matchingTools,
  paletteEntries,
  pushRecent,
  rectToCss,
  stepIndex,
  togglePin,
} from "../app/js/core.js";
import { TOOLS } from "../app/js/tools-data.js";

const item = (str, { x = 60, y = 700, size = 10, width } = {}) => ({
  str,
  transform: [1, 0, 0, size, x, y],
  width: width ?? str.length * size * 0.5,
  height: size,
});

test("fold is a plain lowercase", () => {
  assert.equal(fold("MERGÉ"), "mergé");
  assert.equal(fold(null), "");
});

test("tool filter dims instead of hiding, and matches descriptions/keywords", () => {
  const rows = filterTools(TOOLS, "zoomin");
  assert.equal(rows.length, TOOLS.length, "all tools stay in the palette");
  assert.equal(rows.filter((r) => r.matching).length, 0);

  const byKeyword = matchingTools(TOOLS, "clipboard").map((t) => t.id);
  assert.deepEqual(byKeyword, ["copy-text"]);

  const byDescription = matchingTools(TOOLS, "wrapping").map((t) => t.id);
  assert.ok(byDescription.includes("find-next"));

  const byTitle = matchingTools(TOOLS, "OPEN PDF").map((t) => t.id);
  assert.ok(byTitle.includes("open-file"));

  const empty = filterTools(TOOLS, "   ");
  assert.ok(empty.every((r) => r.matching), "blank query matches everything");
});

test("tool filter keeps original order", () => {
  const rows = filterTools(TOOLS, "search");
  const ids = rows.map((r) => r.tool.id);
  assert.deepEqual(ids, TOOLS.map((t) => t.id));
});

test("pushRecent dedupes, moves to front and caps at 12", () => {
  let recent = [];
  for (let i = 0; i < 15; i += 1) recent = pushRecent(recent, `t${i}`);
  assert.equal(recent.length, 12);
  assert.equal(recent[0], "t14");

  recent = pushRecent(recent, "t10");
  assert.equal(recent[0], "t10");
  assert.equal(recent.filter((id) => id === "t10").length, 1);

  assert.deepEqual(pushRecent(recent, ""), recent);
});

test("pin moves an id out of recents; unpin returns it", () => {
  let state = { pinned: ["find"], recent: ["open-file", "find", "zoom-in"] };
  state = togglePin(state, "open-file");
  assert.deepEqual(state.pinned, ["open-file", "find"]);
  assert.deepEqual(state.recent, ["find", "zoom-in"]);

  state = togglePin(state, "open-file");
  assert.deepEqual(state.pinned, ["find"]);
  assert.deepEqual(state.recent, ["open-file", "find", "zoom-in"]);

  // Unknown ids are still recorded (Sejda also trusts localStorage).
  const unchanged = togglePin({ pinned: [], recent: [] }, "");
  assert.deepEqual(unchanged, { pinned: [], recent: [] });
});

test("palette entries are pins, then recents, then defaults, deduped and capped", () => {
  const ids = paletteEntries({
    pinned: ["find"],
    recent: ["zoom-in", "find"],
    defaults: ["open-file", "zoom-in"],
    limit: 3,
  });
  assert.deepEqual(ids, ["find", "zoom-in", "open-file"]);
});

test("buildLines groups one visual line and inserts a gap space", () => {
  const lines = buildLines([
    item("Hello", { x: 60, width: 25 }),
    item("world", { x: 90, width: 25 }),
    item("Second line", { x: 60, y: 670, width: 55 }),
  ]);
  assert.equal(lines.length, 2);
  assert.equal(lines[0].text, "Hello world");
  assert.equal(lines[1].text, "Second line");
  assert.deepEqual(
    lines[0].segments.map((s) => [s.start, s.end]),
    [
      [0, 5],
      [6, 11],
    ],
  );
});

test("buildLines starts a new line when x jumps back (two columns)", () => {
  const lines = buildLines([
    item("Left column text", { x: 60, y: 700, width: 80 }),
    item("Right column text", { x: 320, y: 700, width: 80 }),
  ]);
  // A large forward jump is treated as a new line segment, not a same-line gap.
  assert.ok(lines.length >= 1);
  // Reading order must still put the left column first.
  assert.ok(lines[0].text.startsWith("Left"));
});

test("findInPage finds every occurrence on a line", () => {
  const model = buildPageModel(
    1,
    [item("merge merge merge", { width: 85 })],
    792,
    612,
  );
  const matches = findInPage(model, "merge");
  assert.equal(matches.length, 3);
  assert.deepEqual(matches.map((m) => m.start), [0, 6, 12]);
  assert.equal(matches[0].pageNumber, 1);
  assert.equal(matches[0].text, "merge");
});

test("match case and whole word behave as options", () => {
  const model = buildPageModel(
    1,
    [item("Merge the merge searcher", { width: 110 })],
    792,
    612,
  );
  assert.equal(findInPage(model, "merge").length, 2);
  assert.equal(findInPage(model, "merge", { wholeWord: true }).length, 2);
  assert.equal(findInPage(model, "merge", { matchCase: true }).length, 1);
  assert.equal(findInPage(model, "merge", { matchCase: true, wholeWord: true }).length, 1);
  assert.equal(findInPage(model, "Merge").length, 2);
  assert.equal(findInPage(model, "").length, 0);
});

test("geometry maps partial matches to proportional rects", () => {
  const line = {
    text: "abcdef",
    segments: [
      { start: 0, end: 3, x: 100, baselineY: 500, width: 30, size: 10 },
      { start: 3, end: 6, x: 130, baselineY: 500, width: 30, size: 10 },
    ],
  };
  const rects = geometryForRange(line, 1, 5);
  assert.equal(rects.length, 2);
  assert.equal(rects[0].x, 110);
  assert.equal(rects[0].width, 20);
  assert.equal(rects[1].x, 130);
  assert.equal(rects[1].width, 20);
});

test("rectToCss flips the PDF baseline into CSS space", () => {
  const css = rectToCss({ x: 10, baselineY: 700, width: 20, size: 10 }, 792, 2);
  assert.equal(css.left, 20);
  assert.equal(css.top, (792 - 700 - 8) * 2);
  assert.equal(css.width, 40);
  assert.equal(css.height, 10 * 0.92 * 2);
});

test("findInDocument walks pages in order", () => {
  const page1 = buildPageModel(1, [item("alpha merge")], 792, 612);
  const page2 = buildPageModel(2, [item("merge beta", { y: 600 })], 792, 612);
  const matches = findInDocument([page1, page2], "merge");
  assert.deepEqual(matches.map((m) => m.pageNumber), [1, 2]);
  assert.deepEqual([...countByPage(matches)], [
    [1, 1],
    [2, 1],
  ]);
});

test("stepIndex wraps in both directions", () => {
  assert.equal(stepIndex(-1, 3), 0);
  assert.equal(stepIndex(2, 3, 1), 0);
  assert.equal(stepIndex(0, 3, -1), 2);
  assert.equal(stepIndex(-1, 3, -1), 2);
  assert.equal(stepIndex(0, 0), -1);
});

test("describeMatches reports position plus page-scoped count", () => {
  const matches = [
    { pageNumber: 1 },
    { pageNumber: 2 },
    { pageNumber: 2 },
  ];
  assert.equal(describeMatches(matches, 1), "2 of 3 · 2 on page 2");
  assert.equal(describeMatches([], 0), "No matches");
});

test("isWordChar treats unicode letters as word characters", () => {
  assert.equal(isWordChar("a"), true);
  assert.equal(isWordChar("é"), true);
  assert.equal(isWordChar("語"), true);
  assert.equal(isWordChar("-"), false);
  assert.equal(isWordChar(""), false);
});
